HTML file ----> index.html
Javascript file ----> script.js
CSS file ----> style.css